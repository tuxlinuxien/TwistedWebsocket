class FrameError(Exception): pass
class ProtocolError(Exception): pass