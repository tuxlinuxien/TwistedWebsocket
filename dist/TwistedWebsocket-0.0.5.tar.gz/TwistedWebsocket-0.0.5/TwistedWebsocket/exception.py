class FrameError(Exception): pass
class WebsocketError(Exception): pass